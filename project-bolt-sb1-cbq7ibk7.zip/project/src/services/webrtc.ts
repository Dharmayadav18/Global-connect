import SimplePeer from 'simple-peer';
import { useCallStore } from '../store/callStore';
import { useUserStore } from '../store/userStore';

// This is a simplified version of what would be a more complex WebRTC implementation
export class WebRTCService {
  private peer: SimplePeer.Instance | null = null;
  private socket: WebSocket | null = null;
  
  constructor() {
    // In a real app, you would connect to your signaling server
    this.socket = new WebSocket('wss://your-signaling-server.com');
    
    this.socket.onmessage = (event) => {
      const data = JSON.parse(event.data);
      
      if (data.type === 'offer') {
        this.handleIncomingCall(data);
      } else if (data.type === 'answer') {
        this.handleCallAccepted(data);
      } else if (data.type === 'ice-candidate') {
        this.handleNewICECandidate(data);
      } else if (data.type === 'call-ended') {
        this.handleCallEnded();
      }
    };
  }
  
  async startCall(receiverId: string, isVideo: boolean): Promise<void> {
    const callStore = useCallStore.getState();
    const userStore = useUserStore.getState();
    
    if (!userStore.currentUser) return;
    
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: isVideo,
        audio: true
      });
      
      callStore.setLocalStream(stream);
      
      this.peer = new SimplePeer({
        initiator: true,
        trickle: false,
        stream
      });
      
      this.peer.on('signal', (data) => {
        // Send the offer to the signaling server
        this.socket?.send(JSON.stringify({
          type: 'offer',
          offer: data,
          from: userStore.currentUser?.id,
          to: receiverId
        }));
      });
      
      this.peer.on('stream', (remoteStream) => {
        callStore.setRemoteStream(remoteStream);
      });
      
      this.peer.on('close', () => {
        this.handleCallEnded();
      });
      
      this.peer.on('error', (err) => {
        console.error('Peer error:', err);
        this.handleCallEnded();
      });
      
    } catch (err) {
      console.error('Error accessing media devices:', err);
    }
  }
  
  acceptIncomingCall(offer: any): void {
    const callStore = useCallStore.getState();
    
    navigator.mediaDevices.getUserMedia({
      video: callStore.currentCall?.type === 'video',
      audio: true
    }).then((stream) => {
      callStore.setLocalStream(stream);
      
      this.peer = new SimplePeer({
        initiator: false,
        trickle: false,
        stream
      });
      
      this.peer.on('signal', (data) => {
        // Send the answer to the signaling server
        this.socket?.send(JSON.stringify({
          type: 'answer',
          answer: data,
          from: useUserStore.getState().currentUser?.id,
          to: callStore.currentCall?.callerId
        }));
      });
      
      this.peer.on('stream', (remoteStream) => {
        callStore.setRemoteStream(remoteStream);
      });
      
      this.peer.on('close', () => {
        this.handleCallEnded();
      });
      
      this.peer.on('error', (err) => {
        console.error('Peer error:', err);
        this.handleCallEnded();
      });
      
      // Signal the peer with the received offer
      this.peer.signal(offer);
      
    }).catch((err) => {
      console.error('Error accessing media devices:', err);
    });
  }
  
  endCall(): void {
    if (this.peer) {
      this.peer.destroy();
      this.peer = null;
    }
    
    const callStore = useCallStore.getState();
    const currentCall = callStore.currentCall;
    
    if (currentCall) {
      this.socket?.send(JSON.stringify({
        type: 'call-ended',
        from: useUserStore.getState().currentUser?.id,
        to: currentCall.callerId === useUserStore.getState().currentUser?.id 
          ? currentCall.receiverId 
          : currentCall.callerId
      }));
    }
    
    callStore.endCall();
  }
  
  private handleIncomingCall(data: any): void {
    // In a real app, you would fetch the caller's information
    // from your backend or store
    const mockCaller = {
      id: data.from,
      name: 'Incoming Caller',
      avatar: `https://source.unsplash.com/random/100x100/?portrait&${data.from}`,
      country: 'Unknown',
      region: 'Unknown',
      interests: [],
      isPremium: false,
      isOnline: true
    };
    
    const incomingCall = {
      id: `call-${Date.now()}`,
      callerId: data.from,
      receiverId: useUserStore.getState().currentUser?.id || '',
      type: data.isVideo ? 'video' : 'audio',
      status: 'ringing'
    };
    
    useCallStore.getState().setIncomingCall(incomingCall, mockCaller);
    
    // Store the offer to use when the call is accepted
    this._pendingOffer = data.offer;
  }
  
  private _pendingOffer: any = null;
  
  private handleCallAccepted(data: any): void {
    if (this.peer) {
      this.peer.signal(data.answer);
    }
  }
  
  private handleNewICECandidate(data: any): void {
    if (this.peer) {
      this.peer.signal(data.candidate);
    }
  }
  
  private handleCallEnded(): void {
    useCallStore.getState().endCall();
  }
}

export const webRTCService = new WebRTCService();