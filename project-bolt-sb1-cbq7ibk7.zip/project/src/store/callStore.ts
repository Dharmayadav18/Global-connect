import { create } from 'zustand';
import { Call, User } from '../types';

interface CallState {
  currentCall: Call | null;
  remoteStream: MediaStream | null;
  localStream: MediaStream | null;
  isCallModalOpen: boolean;
  incomingCall: { call: Call; caller: User } | null;
  
  setCurrentCall: (call: Call | null) => void;
  setRemoteStream: (stream: MediaStream | null) => void;
  setLocalStream: (stream: MediaStream | null) => void;
  openCallModal: () => void;
  closeCallModal: () => void;
  setIncomingCall: (call: Call | null, caller: User | null) => void;
  
  initiateCall: (receiverId: string, type: 'video' | 'audio') => void;
  acceptCall: () => void;
  rejectCall: () => void;
  endCall: () => void;
}

export const useCallStore = create<CallState>((set, get) => ({
  currentCall: null,
  remoteStream: null,
  localStream: null,
  isCallModalOpen: false,
  incomingCall: null,
  
  setCurrentCall: (call) => set({ currentCall: call }),
  setRemoteStream: (stream) => set({ remoteStream: stream }),
  setLocalStream: (stream) => set({ localStream: stream }),
  openCallModal: () => set({ isCallModalOpen: true }),
  closeCallModal: () => set({ isCallModalOpen: false }),
  setIncomingCall: (call, caller) => set({ 
    incomingCall: call && caller ? { call, caller } : null 
  }),
  
  initiateCall: (receiverId, type) => {
    const callId = `call-${Date.now()}`;
    const newCall: Call = {
      id: callId,
      callerId: 'current-user-id', // This would be replaced with actual user ID
      receiverId,
      type,
      status: 'ringing',
      startTime: Date.now()
    };
    
    set({ 
      currentCall: newCall,
      isCallModalOpen: true
    });
    
    // Here you would integrate with your WebRTC solution
    // to actually initiate the call
  },
  
  acceptCall: () => {
    const { incomingCall } = get();
    if (incomingCall) {
      set({
        currentCall: { ...incomingCall.call, status: 'ongoing' },
        incomingCall: null,
        isCallModalOpen: true
      });
      
      // Here you would accept the WebRTC connection
    }
  },
  
  rejectCall: () => {
    set({
      incomingCall: null
    });
    
    // Here you would reject the WebRTC connection
  },
  
  endCall: () => {
    const { currentCall, localStream, remoteStream } = get();
    
    // Stop all tracks in the streams
    if (localStream) {
      localStream.getTracks().forEach(track => track.stop());
    }
    
    if (remoteStream) {
      remoteStream.getTracks().forEach(track => track.stop());
    }
    
    set({
      currentCall: currentCall ? { ...currentCall, status: 'ended', endTime: Date.now() } : null,
      isCallModalOpen: false,
      localStream: null,
      remoteStream: null
    });
    
    // Here you would close the WebRTC connection
  }
}));