import { create } from 'zustand';
import { User } from '../types';

interface UserState {
  currentUser: User | null;
  isAuthenticated: boolean;
  isPremium: boolean;
  setCurrentUser: (user: User) => void;
  login: (id: string, name: string, country: string) => void;
  logout: () => void;
  upgradeToPremium: () => void;
}

export const useUserStore = create<UserState>((set) => ({
  currentUser: null,
  isAuthenticated: false,
  isPremium: false,
  
  setCurrentUser: (user) => set({ 
    currentUser: user, 
    isAuthenticated: true,
    isPremium: user.isPremium
  }),
  
  login: (id, name, country) => set({
    currentUser: {
      id,
      name,
      avatar: `https://source.unsplash.com/random/100x100/?portrait&${id}`,
      country,
      region: getRegionFromCountry(country),
      interests: [],
      isPremium: false,
      isOnline: true
    },
    isAuthenticated: true,
    isPremium: false
  }),
  
  logout: () => set({
    currentUser: null,
    isAuthenticated: false,
    isPremium: false
  }),
  
  upgradeToPremium: () => set((state) => ({
    isPremium: true,
    currentUser: state.currentUser 
      ? { ...state.currentUser, isPremium: true } 
      : null
  }))
}));

// Helper function to determine region from country
function getRegionFromCountry(country: string): string {
  const regions: Record<string, string[]> = {
    'North America': ['USA', 'Canada', 'Mexico'],
    'Europe': ['UK', 'France', 'Germany', 'Italy', 'Spain'],
    'Asia': ['China', 'Japan', 'India', 'South Korea', 'Thailand'],
    'Africa': ['Nigeria', 'Egypt', 'South Africa', 'Kenya', 'Morocco'],
    'South America': ['Brazil', 'Argentina', 'Colombia', 'Peru', 'Chile'],
    'Oceania': ['Australia', 'New Zealand', 'Fiji']
  };
  
  for (const [region, countries] of Object.entries(regions)) {
    if (countries.includes(country)) {
      return region;
    }
  }
  
  return 'Other';
}