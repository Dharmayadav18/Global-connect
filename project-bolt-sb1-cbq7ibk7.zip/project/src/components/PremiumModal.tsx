import React from 'react';
import { useUserStore } from '../store/userStore';
import { Globe, Users, Video, MessageCircle, Check, X } from 'lucide-react';

interface PremiumModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const PremiumModal: React.FC<PremiumModalProps> = ({ isOpen, onClose }) => {
  const { upgradeToPremium } = useUserStore();
  
  const handleUpgrade = () => {
    upgradeToPremium();
    onClose();
    alert('Congratulations! You are now a premium member with global access.');
  };
  
  if (!isOpen) return null;
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-40">
      <div className="bg-white rounded-lg w-full max-w-2xl overflow-hidden">
        <div className="bg-gradient-to-r from-purple-600 to-blue-500 p-6 text-white">
          <h2 className="text-2xl font-bold">Upgrade to Premium</h2>
          <p className="mt-2">Connect with friends around the world without limitations</p>
        </div>
        
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="border rounded-lg p-4">
              <h3 className="font-bold text-lg mb-4 text-gray-700">Free Plan</h3>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <span className="mr-2 text-green-500 mt-0.5"><Check size={16} /></span>
                  <span>Connect with users in your region</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2 text-green-500 mt-0.5"><Check size={16} /></span>
                  <span>Basic video and voice calls</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2 text-red-500 mt-0.5"><X size={16} /></span>
                  <span className="text-gray-400">Connect with users from other regions</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2 text-red-500 mt-0.5"><X size={16} /></span>
                  <span className="text-gray-400">Priority matching</span>
                </li>
              </ul>
              <div className="mt-6 text-center">
                <span className="block text-xl font-bold">$0</span>
                <span className="text-gray-500">Forever</span>
              </div>
            </div>
            
            <div className="border rounded-lg p-4 bg-blue-50 border-blue-200 relative">
              <div className="absolute top-0 right-0 bg-yellow-400 text-yellow-800 text-xs font-bold px-2 py-1 rounded-bl-lg">
                RECOMMENDED
              </div>
              <h3 className="font-bold text-lg mb-4 text-gray-700">Premium Plan</h3>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <span className="mr-2 text-green-500 mt-0.5"><Check size={16} /></span>
                  <span>Connect with users in your region</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2 text-green-500 mt-0.5"><Check size={16} /></span>
                  <span>HD video and voice calls</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2 text-green-500 mt-0.5"><Check size={16} /></span>
                  <span className="font-medium">Connect with users from any region</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2 text-green-500 mt-0.5"><Check size={16} /></span>
                  <span className="font-medium">Priority matching</span>
                </li>
              </ul>
              <div className="mt-6 text-center">
                <span className="block text-xl font-bold">$9.99</span>
                <span className="text-gray-500">per month</span>
              </div>
            </div>
          </div>
          
          <div className="mt-8">
            <h3 className="font-bold text-lg mb-4">Premium Benefits</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="flex flex-col items-center text-center p-3">
                <Globe className="text-blue-500 mb-2" size={32} />
                <h4 className="font-bold">Global Access</h4>
                <p className="text-sm text-gray-600">Connect with people from any region around the world</p>
              </div>
              <div className="flex flex-col items-center text-center p-3">
                <Video className="text-blue-500 mb-2" size={32} />
                <h4 className="font-bold">HD Video</h4>
                <p className="text-sm text-gray-600">Enjoy high-definition video calls with crystal clear quality</p>
              </div>
              <div className="flex flex-col items-center text-center p-3">
                <MessageCircle className="text-blue-500 mb-2" size={32} />
                <h4 className="font-bold">Priority Support</h4>
                <p className="text-sm text-gray-600">Get faster responses and dedicated customer support</p>
              </div>
            </div>
          </div>
          
          <div className="mt-8 flex justify-end space-x-4">
            <button 
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-100"
            >
              Maybe Later
            </button>
            <button 
              onClick={handleUpgrade}
              className="px-4 py-2 bg-gradient-to-r from-purple-600 to-blue-500 rounded-lg text-white hover:opacity-90"
            >
              Upgrade Now
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PremiumModal;