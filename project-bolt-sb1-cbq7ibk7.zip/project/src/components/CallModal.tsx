import React, { useEffect, useRef } from 'react';
import { useCallStore } from '../store/callStore';
import { Mic, MicOff, Video, VideoOff, PhoneOff } from 'lucide-react';

const CallModal: React.FC = () => {
  const { 
    currentCall, 
    localStream, 
    remoteStream, 
    isCallModalOpen, 
    closeCallModal,
    endCall
  } = useCallStore();
  
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);
  
  const [isMuted, setIsMuted] = React.useState(false);
  const [isVideoOff, setIsVideoOff] = React.useState(false);
  
  useEffect(() => {
    if (localVideoRef.current && localStream) {
      localVideoRef.current.srcObject = localStream;
    }
  }, [localStream]);
  
  useEffect(() => {
    if (remoteVideoRef.current && remoteStream) {
      remoteVideoRef.current.srcObject = remoteStream;
    }
  }, [remoteStream]);
  
  const toggleMute = () => {
    if (localStream) {
      const audioTracks = localStream.getAudioTracks();
      audioTracks.forEach(track => {
        track.enabled = !track.enabled;
      });
      setIsMuted(!isMuted);
    }
  };
  
  const toggleVideo = () => {
    if (localStream) {
      const videoTracks = localStream.getVideoTracks();
      videoTracks.forEach(track => {
        track.enabled = !track.enabled;
      });
      setIsVideoOff(!isVideoOff);
    }
  };
  
  const handleEndCall = () => {
    endCall();
    closeCallModal();
  };
  
  if (!isCallModalOpen || !currentCall) {
    return null;
  }
  
  const isVideoCall = currentCall.type === 'video';
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50">
      <div className="bg-gray-900 rounded-lg overflow-hidden w-full max-w-4xl">
        <div className="relative">
          {/* Remote video (full size) */}
          {isVideoCall && remoteStream && (
            <div className="w-full h-[60vh] bg-gray-800">
              <video
                ref={remoteVideoRef}
                autoPlay
                playsInline
                className="w-full h-full object-cover"
              />
            </div>
          )}
          
          {/* Audio-only call display */}
          {(!isVideoCall || !remoteStream) && (
            <div className="w-full h-[60vh] bg-gray-800 flex items-center justify-center">
              <div className="text-center">
                <div className="w-32 h-32 rounded-full bg-gray-700 mx-auto mb-4 flex items-center justify-center">
                  <Phone size={64} className="text-white" />
                </div>
                <h3 className="text-white text-xl font-bold">
                  {currentCall.status === 'ringing' ? 'Calling...' : 'On Call'}
                </h3>
                <p className="text-gray-400">
                  {currentCall.status === 'ongoing' && 'Call in progress'}
                </p>
              </div>
            </div>
          )}
          
          {/* Local video (picture-in-picture) */}
          {isVideoCall && localStream && (
            <div className="absolute bottom-4 right-4 w-1/4 rounded-lg overflow-hidden border-2 border-white">
              <video
                ref={localVideoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover"
              />
            </div>
          )}
        </div>
        
        {/* Call controls */}
        <div className="bg-gray-800 p-4 flex justify-center space-x-6">
          <button
            onClick={toggleMute}
            className={`p-3 rounded-full ${isMuted ? 'bg-red-500' : 'bg-gray-600'}`}
          >
            {isMuted ? <MicOff size={24} className="text-white" /> : <Mic size={24} className="text-white" />}
          </button>
          
          {isVideoCall && (
            <button
              onClick={toggleVideo}
              className={`p-3 rounded-full ${isVideoOff ? 'bg-red-500' : 'bg-gray-600'}`}
            >
              {isVideoOff ? <VideoOff size={24} className="text-white" /> : <Video size={24} className="text-white" />}
            </button>
          )}
          
          <button
            onClick={handleEndCall}
            className="p-3 rounded-full bg-red-600"
          >
            <PhoneOff size={24} className="text-white" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default CallModal;