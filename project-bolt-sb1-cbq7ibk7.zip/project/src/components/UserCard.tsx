import React from 'react';
import { User } from '../types';
import { Video, Phone, MessageCircle, Star } from 'lucide-react';
import { useCallStore } from '../store/callStore';
import { useUserStore } from '../store/userStore';

interface UserCardProps {
  user: User;
  onMessageClick?: (userId: string) => void;
}

const UserCard: React.FC<UserCardProps> = ({ user, onMessageClick }) => {
  const { initiateCall } = useCallStore();
  const { currentUser, isPremium } = useUserStore();
  
  const canConnect = 
    currentUser?.region === user.region || 
    isPremium || 
    !user.isPremium;
  
  const handleVideoCall = () => {
    if (!canConnect) {
      alert('You need a premium subscription to connect with users from other regions');
      return;
    }
    initiateCall(user.id, 'video');
  };
  
  const handleAudioCall = () => {
    if (!canConnect) {
      alert('You need a premium subscription to connect with users from other regions');
      return;
    }
    initiateCall(user.id, 'audio');
  };
  
  const handleMessage = () => {
    if (!canConnect) {
      alert('You need a premium subscription to message users from other regions');
      return;
    }
    if (onMessageClick) onMessageClick(user.id);
  };
  
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="relative">
        <img 
          src={user.avatar} 
          alt={user.name} 
          className="w-full h-48 object-cover"
        />
        <div className="absolute top-2 right-2 flex items-center">
          {user.isPremium && (
            <span className="bg-yellow-400 text-yellow-800 p-1 rounded-full mr-1">
              <Star size={16} />
            </span>
          )}
          <span className={`h-3 w-3 rounded-full ${user.isOnline ? 'bg-green-500' : 'bg-gray-400'}`}></span>
        </div>
      </div>
      
      <div className="p-4">
        <h3 className="font-bold text-lg">{user.name}</h3>
        <p className="text-gray-600 text-sm">{user.country} • {user.region}</p>
        
        <div className="mt-2">
          {user.interests.map((interest, index) => (
            <span 
              key={index} 
              className="inline-block bg-gray-200 rounded-full px-3 py-1 text-xs font-semibold text-gray-700 mr-2 mb-2"
            >
              {interest}
            </span>
          ))}
        </div>
        
        <div className="mt-4 flex justify-between">
          <button 
            onClick={handleVideoCall}
            className={`p-2 rounded-full ${canConnect ? 'bg-blue-500 text-white' : 'bg-gray-300 text-gray-500'}`}
            disabled={!canConnect}
          >
            <Video size={20} />
          </button>
          
          <button 
            onClick={handleAudioCall}
            className={`p-2 rounded-full ${canConnect ? 'bg-green-500 text-white' : 'bg-gray-300 text-gray-500'}`}
            disabled={!canConnect}
          >
            <Phone size={20} />
          </button>
          
          <button 
            onClick={handleMessage}
            className={`p-2 rounded-full ${canConnect ? 'bg-purple-500 text-white' : 'bg-gray-300 text-gray-500'}`}
            disabled={!canConnect}
          >
            <MessageCircle size={20} />
          </button>
        </div>
        
        {!canConnect && (
          <div className="mt-2 text-center text-xs text-red-500">
            Premium required to connect
          </div>
        )}
      </div>
    </div>
  );
};

export default UserCard;