import React from 'react';
import { useCallStore } from '../store/callStore';
import { Phone, Video, PhoneOff } from 'lucide-react';

const IncomingCallModal: React.FC = () => {
  const { incomingCall, acceptCall, rejectCall } = useCallStore();
  
  if (!incomingCall) {
    return null;
  }
  
  const { call, caller } = incomingCall;
  const isVideoCall = call.type === 'video';
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg overflow-hidden w-full max-w-md">
        <div className="p-6 text-center">
          <div className="w-24 h-24 rounded-full mx-auto mb-4 overflow-hidden">
            <img 
              src={caller.avatar} 
              alt={caller.name} 
              className="w-full h-full object-cover"
            />
          </div>
          
          <h3 className="text-xl font-bold mb-1">{caller.name}</h3>
          <p className="text-gray-600 mb-4">{caller.country}</p>
          
          <div className="flex items-center justify-center mb-4">
            {isVideoCall ? (
              <div className="flex items-center text-blue-600">
                <Video size={20} className="mr-2" />
                <span>Incoming video call</span>
              </div>
            ) : (
              <div className="flex items-center text-green-600">
                <Phone size={20} className="mr-2" />
                <span>Incoming voice call</span>
              </div>
            )}
          </div>
          
          <div className="flex justify-center space-x-6">
            <button
              onClick={rejectCall}
              className="p-4 rounded-full bg-red-500 text-white"
            >
              <PhoneOff size={24} />
            </button>
            
            <button
              onClick={acceptCall}
              className={`p-4 rounded-full ${isVideoCall ? 'bg-blue-500' : 'bg-green-500'} text-white`}
            >
              {isVideoCall ? <Video size={24} /> : <Phone size={24} />}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default IncomingCallModal;