import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useUserStore } from './store/userStore';
import Login from './pages/Login';
import Discover from './pages/Discover';
import CallModal from './components/CallModal';
import IncomingCallModal from './components/IncomingCallModal';

function App() {
  const { isAuthenticated } = useUserStore();
  
  // Protected route component
  const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
    if (!isAuthenticated) {
      return <Navigate to="/" replace />;
    }
    
    return <>{children}</>;
  };
  
  return (
    <Router>
      <div className="min-h-screen bg-gray-100">
        <Routes>
          <Route path="/" element={<Login />} />
          <Route 
            path="/discover" 
            element={
              <ProtectedRoute>
                <Discover />
              </ProtectedRoute>
            } 
          />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
        
        {/* These modals are rendered globally */}
        <CallModal />
        <IncomingCallModal />
      </div>
    </Router>
  );
}

export default App;