export interface User {
  id: string;
  name: string;
  avatar: string;
  country: string;
  region: string;
  interests: string[];
  isPremium: boolean;
  isOnline: boolean;
}

export interface Message {
  id: string;
  senderId: string;
  receiverId: string;
  content: string;
  timestamp: number;
}

export interface Call {
  id: string;
  callerId: string;
  receiverId: string;
  type: 'video' | 'audio';
  status: 'ringing' | 'ongoing' | 'ended';
  startTime?: number;
  endTime?: number;
}

export interface Region {
  id: string;
  name: string;
  countries: string[];
  isPremiumOnly: boolean;
}