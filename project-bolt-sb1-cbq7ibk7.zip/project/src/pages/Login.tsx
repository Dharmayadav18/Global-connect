import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useUserStore } from '../store/userStore';
import { Video, Users, MessageCircle, Globe } from 'lucide-react';

const Login: React.FC = () => {
  const [name, setName] = useState('');
  const [country, setCountry] = useState('USA');
  const { login } = useUserStore();
  const navigate = useNavigate();
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim() && country) {
      login(`user-${Date.now()}`, name, country);
      navigate('/discover');
    }
  };
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-500 to-purple-600 flex flex-col items-center justify-center p-4">
      <div className="max-w-md w-full bg-white rounded-xl shadow-xl overflow-hidden">
        <div className="p-8">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-800">GlobalConnect</h1>
            <p className="text-gray-600 mt-2">Connect with friends around the world</p>
          </div>
          
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                Your Name
              </label>
              <input
                id="name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder="Enter your name"
                required
              />
            </div>
            
            <div>
              <label htmlFor="country" className="block text-sm font-medium text-gray-700 mb-1">
                Your Country
              </label>
              <select
                id="country"
                value={country}
                onChange={(e) => setCountry(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                required
              >
                <optgroup label="North America">
                  <option value="USA">United States</option>
                  <option value="Canada">Canada</option>
                  <option value="Mexico">Mexico</option>
                </optgroup>
                <optgroup label="Europe">
                  <option value="UK">United Kingdom</option>
                  <option value="France">France</option>
                  <option value="Germany">Germany</option>
                  <option value="Italy">Italy</option>
                  <option value="Spain">Spain</option>
                </optgroup>
                <optgroup label="Asia">
                  <option value="China">China</option>
                  <option value="Japan">Japan</option>
                  <option value="India">India</option>
                  <option value="South Korea">South Korea</option>
                  <option value="Thailand">Thailand</option>
                </optgroup>
                <optgroup label="Africa">
                  <option value="Nigeria">Nigeria</option>
                  <option value="Egypt">Egypt</option>
                  <option value="South Africa">South Africa</option>
                  <option value="Kenya">Kenya</option>
                  <option value="Morocco">Morocco</option>
                </optgroup>
                <optgroup label="South America">
                  <option value="Brazil">Brazil</option>
                  <option value="Argentina">Argentina</option>
                  <option value="Colombia">Colombia</option>
                  <option value="Peru">Peru</option>
                  <option value="Chile">Chile</option>
                </optgroup>
                <optgroup label="Oceania">
                  <option value="Australia">Australia</option>
                  <option value="New Zealand">New Zealand</option>
                  <option value="Fiji">Fiji</option>
                </optgroup>
              </select>
            </div>
            
            <button
              type="submit"
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-2 rounded-lg font-medium hover:opacity-90 transition-opacity"
            >
              Get Started
            </button>
          </form>
        </div>
        
        <div className="bg-gray-50 px-8 py-6">
          <h2 className="text-center text-gray-700 font-medium mb-4">Connect with friends through:</h2>
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-center">
              <Video className="text-blue-500 mr-2" size={20} />
              <span className="text-sm">Video Calls</span>
            </div>
            <div className="flex items-center">
              <MessageCircle className="text-purple-500 mr-2" size={20} />
              <span className="text-sm">Messaging</span>
            </div>
            <div className="flex items-center">
              <Users className="text-green-500 mr-2" size={20} />
              <span className="text-sm">Friend Matching</span>
            </div>
            <div className="flex items-center">
              <Globe className="text-red-500 mr-2" size={20} />
              <span className="text-sm">Global Network</span>
            </div>
          </div>
        </div>
      </div>
      
      <p className="text-white text-sm mt-8 text-center max-w-md">
        By continuing, you agree to our Terms of Service and Privacy Policy.
        Your data is securely protected.
      </p>
    </div>
  );
};

export default Login;