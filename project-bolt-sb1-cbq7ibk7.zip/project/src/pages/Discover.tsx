import React, { useState, useEffect } from 'react';
import UserCard from '../components/UserCard';
import { User } from '../types';
import { useUserStore } from '../store/userStore';
import { Search, Filter, Globe, MapPin } from 'lucide-react';
import PremiumModal from '../components/PremiumModal';

// Mock data for demonstration
const mockUsers: User[] = [
  {
    id: 'user1',
    name: 'Alex Johnson',
    avatar: 'https://source.unsplash.com/random/200x200/?portrait&1',
    country: 'USA',
    region: 'North America',
    interests: ['Photography', 'Travel', 'Music'],
    isPremium: true,
    isOnline: true
  },
  {
    id: 'user2',
    name: 'Emma Wilson',
    avatar: 'https://source.unsplash.com/random/200x200/?portrait&2',
    country: 'UK',
    region: 'Europe',
    interests: ['Books', 'Movies', 'Art'],
    isPremium: false,
    isOnline: true
  },
  {
    id: 'user3',
    name: 'Hiroshi Tanaka',
    avatar: 'https://source.unsplash.com/random/200x200/?portrait&3',
    country: 'Japan',
    region: 'Asia',
    interests: ['Gaming', 'Anime', 'Technology'],
    isPremium: true,
    isOnline: false
  },
  {
    id: 'user4',
    name: 'Maria Rodriguez',
    avatar: 'https://source.unsplash.com/random/200x200/?portrait&4',
    country: 'Mexico',
    region: 'North America',
    interests: ['Cooking', 'Dancing', 'Languages'],
    isPremium: false,
    isOnline: true
  },
  {
    id: 'user5',
    name: 'Priya Patel',
    avatar: 'https://source.unsplash.com/random/200x200/?portrait&5',
    country: 'India',
    region: 'Asia',
    interests: ['Yoga', 'Meditation', 'Travel'],
    isPremium: false,
    isOnline: true
  },
  {
    id: 'user6',
    name: 'Lucas Silva',
    avatar: 'https://source.unsplash.com/random/200x200/?portrait&6',
    country: 'Brazil',
    region: 'South America',
    interests: ['Soccer', 'Beach', 'Music'],
    isPremium: true,
    isOnline: true
  }
];

const Discover: React.FC = () => {
  const { currentUser, isPremium } = useUserStore();
  const [users, setUsers] = useState<User[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRegion, setSelectedRegion] = useState<string>('');
  const [showPremiumModal, setShowPremiumModal] = useState(false);
  
  useEffect(() => {
    // In a real app, you would fetch users from your backend
    // Filter out the current user from the list
    const filteredUsers = mockUsers.filter(user => 
      user.id !== currentUser?.id
    );
    setUsers(filteredUsers);
  }, [currentUser]);
  
  const filteredUsers = users.filter(user => {
    const matchesSearch = 
      user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.country.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.interests.some(interest => 
        interest.toLowerCase().includes(searchTerm.toLowerCase())
      );
      
    const matchesRegion = selectedRegion ? user.region === selectedRegion : true;
    
    return matchesSearch && matchesRegion;
  });
  
  const regions = Array.from(new Set(users.map(user => user.region)));
  
  const handleMessageClick = (userId: string) => {
    // In a real app, you would navigate to a chat page or open a chat modal
    console.log(`Opening chat with user ${userId}`);
  };
  
  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-gray-900">Discover Friends</h1>
          
          {!isPremium && (
            <button
              onClick={() => setShowPremiumModal(true)}
              className="bg-gradient-to-r from-purple-600 to-blue-500 text-white px-4 py-2 rounded-lg text-sm font-medium hover:opacity-90"
            >
              <Globe className="inline-block mr-1" size={16} />
              Upgrade to Premium
            </button>
          )}
        </div>
      </header>
      
      <main className="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
        <div className="mb-6 flex flex-col md:flex-row gap-4">
          <div className="relative flex-grow">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
              placeholder="Search by name, country, or interests"
            />
          </div>
          
          <div className="relative md:w-64">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <MapPin className="h-5 w-5 text-gray-400" />
            </div>
            <select
              value={selectedRegion}
              onChange={(e) => setSelectedRegion(e.target.value)}
              className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 appearance-none"
            >
              <option value="">All Regions</option>
              {regions.map((region) => (
                <option key={region} value={region}>
                  {region}
                </option>
              ))}
            </select>
          </div>
        </div>
        
        {!isPremium && (
          <div className="mb-6 bg-blue-50 border border-blue-200 rounded-lg p-4 flex items-center">
            <Globe className="text-blue-500 mr-3 flex-shrink-0" size={24} />
            <div>
              <h3 className="font-medium text-blue-800">Unlock Global Connections</h3>
              <p className="text-blue-600 text-sm">
                Upgrade to premium to connect with friends from any region around the world.
                <button 
                  onClick={() => setShowPremiumModal(true)}
                  className="ml-2 text-blue-800 underline font-medium"
                >
                  Learn more
                </button>
              </p>
            </div>
          </div>
        )}
        
        {filteredUsers.length === 0 ? (
          <div className="text-center py-12">
            <Filter className="mx-auto h-12 w-12 text-gray-400" />
            <h3 className="mt-2 text-lg font-medium text-gray-900">No users found</h3>
            <p className="mt-1 text-gray-500">Try adjusting your search or filter criteria.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredUsers.map((user) => (
              <UserCard 
                key={user.id} 
                user={user} 
                onMessageClick={handleMessageClick}
              />
            ))}
          </div>
        )}
      </main>
      
      <PremiumModal 
        isOpen={showPremiumModal} 
        onClose={() => setShowPremiumModal(false)} 
      />
    </div>
  );
};

export default Discover;